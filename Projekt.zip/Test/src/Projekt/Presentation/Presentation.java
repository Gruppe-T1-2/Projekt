package Projekt.Presentation;

public class Presentation {

    public static void addItem(ItemGFX itemGFX) {
        Display.inventory.addItem(itemGFX);

    }
}
